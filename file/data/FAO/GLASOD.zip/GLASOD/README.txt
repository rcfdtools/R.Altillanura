GLASOD 	Read me first


The GLASOD directory also contains an MS Excel file, GLASOD.xls. This file contains the 
attribute data, just like the ArcGIS attribute file, but also contains some explanations (as 
comments in the column header).

The GLASOD map was originally published in 1990 together with a full explanatory note and (in 
1991) additional statistics. Please approach ISRIC for more information.



GVL 06-03
